package kap02_variablen;

/**
 * Eingabe von Daten.
 */
public class Ausgabe {

  /**
   * Verschiedene Formen der Eingabe.
   */
  public static void main(String[] args) {
    System.out.print("Hallo  Welt!");
    System.out.println("Hallo  Welt!");
    System.out.format("Wert: %d", 23);
  }
}
