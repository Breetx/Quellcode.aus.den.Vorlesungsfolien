package kap02_variablen;

/**
 * Experimente mit Literalen.
 *
 */
public class Literale {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    // Binärzahlen
    int binaerZahl1 = 0b11111111111111111111111111111111; // -1
    int binaerZahl2 = 0b10000000000000000000000000000000; // MAX_NEGATIVE_INTEGER
    int binaerZahl3 = 0b00000000000000000000000000000001; // 1
    System.out.println(binaerZahl1);
    System.out.println(binaerZahl2);
    System.out.println(binaerZahl3);
    System.out.println();

    // Oktalzahlen
    int oktalZahl1 = 0000000001; // 1
    int oktalZahl2 = 01; // 1
    System.out.println(oktalZahl1);
    System.out.println(oktalZahl2);
    System.out.println();

    // Hexadezimalzahlen
    int hexadezimalZahl1 = 0xFFFFFFFE; // -2
    int hexadezimalZahl2 = 0x00000001; // 1
    System.out.println(hexadezimalZahl1);
    System.out.println(hexadezimalZahl2);
  }

}
