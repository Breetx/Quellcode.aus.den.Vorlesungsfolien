package kap02_variablen;

/**
 * Experimentierklasse für Zahlensysteme.
 */
public class ZahlenSysteme {
  /**
   * Programmeinstieg
   */
  public static void main(String[] args) {
    int zahlDezimal = -23;
    int zahlHexadezimal = -0x17;
    int zahlOktal = -027;
    int zahlBinaer = -0b10111;
    
    System.out.println(zahlDezimal);
    System.out.println(zahlHexadezimal);
    System.out.println(zahlOktal);
    System.out.println(zahlBinaer);
  }
}
