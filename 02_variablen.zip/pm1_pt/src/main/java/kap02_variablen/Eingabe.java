package kap02_variablen;

import java.util.Scanner;

/**
 * Einabe von Daten durch BenutzerIn.
 */
public class Eingabe {

  /**
   * Eingabe durch BenutzerIn.
   */
  public static void main(String[] args) {
    // Achtung: benötigt import von java.util.Scanner
    Scanner scanner = new Scanner(System.in);
    System.out.println("Bitte Eingabe eintippen und <Enter> drücken.");
    String eingabeText = scanner.nextLine();
    System.out.println("Text-Eingabe auf Konsole: " + eingabeText);
    // Achtung: die folgende Zeile funktioniert nur, wenn auch eine Zahl
    // eingegeben wurde!
    int eingabeZahl = scanner.nextInt();
    System.out.println("Umwandlung in Zahl: " + eingabeZahl);
    scanner.close();
  }
}
