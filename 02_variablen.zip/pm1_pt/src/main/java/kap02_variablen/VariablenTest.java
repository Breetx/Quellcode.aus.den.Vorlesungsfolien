package kap02_variablen;

/**
 * Einführung von Variablen, Syntax.
 *
 */
public class VariablenTest {

  /**
   * Deklaration, Initialisierung und Ausgabe des Inhalts einer Variable.
   */
  public static void main(String[] args) {
    int geld;
    geld = 23;
    System.out.println(geld);
  }
}
