package kap08_konstruktoren;

/**
 * Testklasse zum Experimentieren mit Brüchen.
 */
public class BruchAnwendung {

  /**
   * Programmeinstiegs-Methode.
   */
  public static void main(String[] args) {
    Bruch bruch = new Bruch(2, 3);
    bruch.print();

    Bruch original = new Bruch(2, 7);
    Bruch kopie = new Bruch(original);
    kopie.print(); // gibt 2/7 aus
    
    Bruch bruch1 = new Bruch(2, 7);
    Bruch bruch2 = new Bruch(3, 2);
    Bruch ergebnis = bruch1.addiereDazuFinal(bruch2);
    ergebnis.print(); // Ausgabe: 25,14

  }
}
