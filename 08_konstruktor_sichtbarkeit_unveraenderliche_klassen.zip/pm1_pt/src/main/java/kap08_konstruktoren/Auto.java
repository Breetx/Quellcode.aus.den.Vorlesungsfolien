package kap08_konstruktoren;

/**
 * Repräsenation eines Auto, dessen Tankinhalt bei Fahrten simuliert wird.
 * 
 * @author Philipp Jenke
 *
 */
public class Auto {
  /**
   * Fahrzeugtyp
   */
  private String name = "Stadtflitzer";

  /**
   * Fassungsvermögen des Tanks in Liter.
   */
  private double tankkapazitaet = 32;

  /**
   * Aktueller Inhalt des Tanks in Liter.
   */
  private double tankinhalt = 32;

  /**
   * Verbr auch in Liter auf 100 km.
   */
  private double verbrauch = 8;

  /**
   * Gefahrene Strecke seit dem letzten Volltanken.
   */
  private double gefahreneStrecke = 0;

  /**
   * Konstruktor ohne Parameter (Umsetzung des Defauls-Konstruktors).
   */
  private Auto() {
    this("Stadtflitzer", 32, 32, 8, 0);
  }

  /**
   * Konstruktor zur Initialisierung aller Objektvariablen.
   */
  public Auto(String name, double tankkapazitaet, double tankinhalt,
      double verbrauch, double gefahreneStrecke) {
    this.name = name;
    this.tankkapazitaet = tankkapazitaet;
    this.tankinhalt = tankinhalt;
    this.verbrauch = verbrauch;
    this.gefahreneStrecke = gefahreneStrecke;
  }

  /**
   * Fahren einer vorgegebenen Strecke, anpassen des Tankinhalts.
   * 
   * @param entfernung
   *          Gefahrene Strecke.
   */
  public void fahren(double entfernung) {
    gefahreneStrecke += entfernung;
    tankinhalt -= entfernung * verbrauch / 100.0;
  }

  /**
   * Volltanken des Tanks, zurücksetzen der gefahrenen Strecke.
   */
  public void vollTanken() {
    tankinhalt = tankkapazitaet;
    gefahreneStrecke = 0;
  }

  /**
   * Erzeugt eine "Selbstdarstellung" des Objektzustands als Zeichenkette.
   */
  public String toString() {
    String beschreibung = "";
    beschreibung += "name: " + name + "\n";
    beschreibung += "tankkapazitaet: " + tankkapazitaet + "\n";
    beschreibung += "tankinhalt: " + tankinhalt + "\n";
    beschreibung += "verbrauch: " + verbrauch + "\n";
    beschreibung += "gefahreneStrecke: " + gefahreneStrecke + "\n";
    return beschreibung;
  }

  /**
   * Gibt die "Selbstdarstellung" des Objektes auf der Konsole aus.
   */
  public void gibInformationenAus() {
    System.out.println(toString());
  }

  /**
   * Programmeinstieg.
   * 
   * @param args
   *          Kommandozeilenargumente.
   */
  public static void main(String[] args) {
    Auto auto = new Auto();
    auto.fahren(330);
    auto.fahren(330);
    auto.gibInformationenAus();
    auto.vollTanken();
    auto.gibInformationenAus();
  }
}
