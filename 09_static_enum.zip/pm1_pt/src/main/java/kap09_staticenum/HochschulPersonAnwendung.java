package kap09_staticenum;

/**
 * Testanwendung für den Umgang mit Enums.
 */
public class HochschulPersonAnwendung {

  /**
   * Aufzählungstyp für die Kategorien.
   */
  public enum HochschulPerson {
    STUDENT, PROFESSOR, MITARBEITER
  }

  /**
   * Gibt das Durchschnittsalter für jede Kategorie auf der Konsole aus.
   */
  public static void printDurchschnittsalter(HochschulPerson person) {
    System.out.print("Durchschnittsalter: ");
    switch (person) {
      case STUDENT:
        System.out.println(24);
        break;
      case PROFESSOR:
        System.out.println(45);
        break;
      case MITARBEITER:
        System.out.println(41);
        break;
      default:
        System.out.println("-");
    }
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    HochschulPerson person = HochschulPerson.MITARBEITER;
    printDurchschnittsalter(person);
  }
}
