package kap09_staticenum;

import static java.lang.Math.*;

/**
 * Test für statischen Import.
 * 
 * author: Philipp Jenke
 */
public class StatischerImport {

  /**
   * Programmeinstieg
   */
  public static void main(String[] args) {
    double sinWinkel = sin(2 * PI);
    System.out.println(sinWinkel);
  }
}
