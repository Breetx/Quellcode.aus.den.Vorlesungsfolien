package kap09_staticenum;

/**
 * Repräsentation eines Displays in einem Mobiltelefon.
 */
public class Display {
  /**
   * Größe des Geräts in inch.
   */
  private double groesse;

  /**
   * Konstruktor.
   */
  public Display(double groesse) {
    this.groesse = groesse;
  }

  /**
   * Gibt einen Text auf der Konsole aus.
   */
  public void gibAus(String text) {
    System.out.println(text);
  }

  /**
   * Getter.
   */
  public double getGroesse() {
    return groesse;
  }
}
