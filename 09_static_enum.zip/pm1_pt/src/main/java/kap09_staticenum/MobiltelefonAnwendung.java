package kap09_staticenum;

/**
 * Testanwendung für das Mobiltelefon.
 */
public class MobiltelefonAnwendung {
  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Mobiltelefon telefon = new Mobiltelefon(new Display(6.5), "Motorola");
    telefon.rufeAn("Hallo?!?");
  }
}
