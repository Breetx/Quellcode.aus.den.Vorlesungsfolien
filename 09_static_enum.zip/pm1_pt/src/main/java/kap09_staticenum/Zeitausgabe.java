package kap09_staticenum;

import java.time.LocalTime;

/**
 * Hilfsklasse zur Ausgabe der altuellen Zeit auf der Konsole.
 *
 */
public class Zeitausgabe {

  /**
   * Zählt die Anzahle der Aufrufe der Methode gibAus.
   */
  private static int zaehler = 0;

  /**
   * Gib die aktuelle Zeit auf der Konsole aus.
   */
  public static void gibAus() {
    zaehler++;
    LocalTime zeit = LocalTime.now();
    System.out.println(zaehler + ": " + zeit);
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Zeitausgabe.gibAus();
    Zeitausgabe.gibAus();
    Zeitausgabe.gibAus();
  }
}
