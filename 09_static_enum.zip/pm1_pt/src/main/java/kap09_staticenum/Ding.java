package kap09_staticenum;

/**
 * Kontainerklasse für Dinge, die bei der Erzeugung automatisch eine eindeutige
 * Seriennummer bekommen.
 * 
 */
public class Ding {
  /**
   * Statischer Zaehler.
   */
  private static int objektZaehler = 0;

  /**
   * Eindeutige Seriennummer.
   */
  private int seriennummer;

  /**
   * Default Konstruktor.
   */
  public Ding() {
    objektZaehler++;
    seriennummer = objektZaehler;
  }

  /**
   * Getter.
   */
  int getSerienNummer() {
    return seriennummer;
  }

  /**
   * Getter.
   */
  public static int getObjektZaehler() {
    return objektZaehler;
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Ding ding1 = new Ding();
    System.out.println("Seriennummer von Ding 1: " + ding1.getSerienNummer());
    Ding ding2 = new Ding();
    System.out.println("Seriennummer von Ding 2: " + ding2.getSerienNummer());
  }

}
