package kap09_staticenum;

/**
 * Repräsentation eines Mobiltelefons.
 */
public class Mobiltelefon {

  /**
   * Typ des Geräts.
   */
  private String typ;

  /**
   * Referenz auf das Display.
   */
  private Display display;

  /**
   * Konstruktor.
   */
  public Mobiltelefon(Display display, String typ) {
    this.display = display;
    this.typ = typ;
  }

  /**
   * Getter.
   */
  public String getTyp() {
    return typ;
  }

  /**
   * Getter.
   */
  public Display getDisplay() {
    return display;
  }

  /**
   * Anrufen: hier umgesetzt als Ausgabe eines Texts auf dem Display.
   */
  public void rufeAn(String text) {
    display.gibAus(typ + ": " + text);
  }
}
