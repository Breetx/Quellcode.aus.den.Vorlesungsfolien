package kap05_schleifen;

import java.util.Scanner;

/**
 * Frage so lange Zahlen vom Anwender ab, bis er/sie 23 eingibt.
 */
public class EndeMitZahl {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Scanner scanner =
        new Scanner(System.in);
    int eingabe;
    while (true) {
      System.out
          .println("Bitte nächste Zahl eingeben, Ende mit 23.");
      eingabe = scanner.nextInt();
      if (eingabe == 23) {
        break;
      }
    }
    scanner.close();
    System.out.println("Ende");
  }
}
