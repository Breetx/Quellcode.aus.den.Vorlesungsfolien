package kap05_schleifen;

/**
 * Teilt eine Zahl durch Zahlen aus -2, -1, ... 2, bis die Zahl den Wert 0
 * erreicht.
 */
public class TeileZahl {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    int zahl = 10;
    while (zahl != 0) {
      int nenner =
          (int) (Math.random() * 5) - 2;
//      System.out.println("nenner: "
//          + nenner);
      if (nenner == 0) {
        continue;
      }
      zahl = zahl / nenner;
      System.out.println("Zahl: "
          + zahl);
    }
  }

}
