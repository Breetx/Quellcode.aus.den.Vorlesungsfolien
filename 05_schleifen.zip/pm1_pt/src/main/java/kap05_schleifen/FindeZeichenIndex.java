package kap05_schleifen;

/**
 * Suche den (ASCII)-Index des Zeichens 'a'.
 */
public class FindeZeichenIndex {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    System.out
        .println("Suche nach (ASCII)-Index des Buchstabens 'a' ...");
    int zeichenIndex = 0;
    while ((char) zeichenIndex != 'a') {
      zeichenIndex += 1;
    }
    System.out
        .format(
            "Der Buchstabe 'a' hat den Code %d.\n",
            zeichenIndex);
  }
}
