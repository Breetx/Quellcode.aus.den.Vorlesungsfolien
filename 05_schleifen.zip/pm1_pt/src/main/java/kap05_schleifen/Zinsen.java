package kap05_schleifen;

/**
 * Berechnung eines jährlichen Anstiegs eines Betrags mit einer gegebenen
 * Verzinsung.
 */
public class Zinsen {

  /**
   * Berechnung des verzinsten Guthabens.
   */
  public static void main(String[] args) {
    double betrag = 100;
    double zinsen = 3.4;
    int laufzeit = 10;

    for (int jahrZaehler = 0; jahrZaehler < laufzeit; jahrZaehler++) {
      betrag = betrag + betrag * zinsen / 100;
      // Achtung: formatierte Ausgabe mit .format -> siehe API
      System.out.format("Jahr %d: %.2f\n", jahrZaehler + 1, betrag);
    }
  }

}
