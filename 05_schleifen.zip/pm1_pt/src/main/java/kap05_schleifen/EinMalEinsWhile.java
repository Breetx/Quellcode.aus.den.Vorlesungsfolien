package kap05_schleifen;

/**
 * Gibt das 1x1 bis 100 in Matrix-Darstellung aus.
 */
public class EinMalEinsWhile {

  /**
   * Umsetzung mit einer while-Schleife.
   */
  public static void main(String[] args) {
    int indexI = 1;
    int indexJ;
    while (indexI <= 10) { // äußere Schleife
      indexJ = 1;
      while (indexJ <= 10) { // innere Schleife
        System.out.format("%4d", indexI * indexJ);
        indexJ++;
      }
      indexI++;
      System.out.println(); // Neue Zeile
    }
  }
}
