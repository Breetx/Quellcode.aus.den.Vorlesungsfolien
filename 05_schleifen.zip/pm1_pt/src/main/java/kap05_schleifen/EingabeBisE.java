package kap05_schleifen;

import java.util.Scanner;

/**
 * Dieses Programm fragt vom Anwender solange beliebige Zeichen ab, bis er/sie
 * ein 'e' eingibt. Dann endet das Programm.
 */
public class EingabeBisE {
  /**
   * Umsetzung des Programms.
   */
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    char zeichen = ' ';
    System.out.println("Bitte Zeichen eingeben. Ende mit 'e'.");
    do {
      zeichen = scanner.next().charAt(0);
      System.out.println("Eingegebenes Zeichen: " + zeichen);
    } while (zeichen != 'e');
    scanner.close();
    System.out.println("Ende.");
  }
}
