package kap05_schleifen;

/**
 * Gibt das 1x1 bis 100 in Matrix-Darstellung aus.
 */
public class EinMalEinsFor {

  /**
   * Umsetzung mit einer for-Schleife.
   */
  public static void main(String[] args) {
    for (int indexI = 1; indexI <= 10; indexI++) { // äußere Schleife
      for (int indexJ = 1; indexJ <= 10; indexJ++) { // innere Schleife
        System.out.format("%4d", indexI * indexJ);
      }
      System.out.println();
    }

  }
}
