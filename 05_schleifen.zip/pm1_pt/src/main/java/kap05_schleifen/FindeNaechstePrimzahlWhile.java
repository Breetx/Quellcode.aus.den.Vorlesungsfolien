package kap05_schleifen;

/**
 * Findet die nächst größere Primzahl nach einer Startzahl.
 */
public class FindeNaechstePrimzahlWhile {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    boolean istPrimzahl = false;
    int zahl = 123;
    do {
      zahl++;
      istPrimzahl = true;
      for (int i = 2; i < zahl; i++) {
        if (zahl % i == 0) {
          istPrimzahl = false;
          break;
        }
      }
    } while (!istPrimzahl);
    System.out.println(zahl);
  }
}
