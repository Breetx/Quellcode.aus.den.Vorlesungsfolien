package kap05_schleifen;

/**
 * Würfeln von W6-Zufallszahlen, bis eine 6 gewürfelt wurde.
 */
public class WuerfelnWhile {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    int wurf =
        (int) (6 * Math.random()) + 1;
    System.out.format("Wurf: %d.\n",
        wurf);
    while (wurf != 6) {
      wurf =
          (int) (6 * Math.random()) + 1;
      System.out.format("Wurf: %d.\n",
          wurf);
    }
  }
}
