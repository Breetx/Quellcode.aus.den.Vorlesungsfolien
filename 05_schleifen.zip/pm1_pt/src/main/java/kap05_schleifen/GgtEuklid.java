package kap05_schleifen;

import java.util.Scanner;

/**
 * Berechnet den größten gemeinsamen Teiler zweier Ganzzahlen mit dem Algothmus
 * von Euklid.
 */
public class GgtEuklid {

  /**
   * Umsetzung des Algorithmus, Abfragen der Eingabe vom Benutzer, Ausgabe des
   * Ergebnisses auf der Konsole.
   */
  public static void main(String[] args) {
    
    // Eingabe
    Scanner scanner = new Scanner(System.in);
    System.out.println("Bitte erste Zahl eingeben:");
    int zahl1 = scanner.nextInt();
    System.out.println("Bitte zweite Zahl eingeben:");
    int zahl2 = scanner.nextInt();
    scanner.close();
    
    // Berechnung
    int ergebnis = 0;
    if (zahl1 == 0) {
      ergebnis = zahl2;
    } else {
      while (zahl2 != 0) {
        if (zahl1 > zahl2) {
          zahl1 = zahl1 - zahl2;
        } else {
          zahl2 = zahl2 - zahl1;
        }
      }
      ergebnis = zahl1;
    }
    
    // Ausgabe
    System.out.println("Ergebnis = " + ergebnis);
  }

}
