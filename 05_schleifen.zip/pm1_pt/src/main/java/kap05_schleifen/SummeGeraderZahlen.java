package kap05_schleifen;

import java.util.Scanner;

/**
 * Berechnet die Summe aller geraden Zahlen aus Nutzereigaben.
 */
public class SummeGeraderZahlen {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Scanner scanner =
        new Scanner(System.in);
    int zahl;
    int summe = 0;
    do {
      System.out
          .println("Bitte nächste Zahl eingeben, 0 für Ende.");
      zahl = scanner.nextInt();
      if (zahl % 2 == 1) {
        continue;
      }
      summe += zahl;
    } while (zahl != 0);
    System.out.println("Summe: "
        + summe + ".");
    scanner.close();
  }
}
