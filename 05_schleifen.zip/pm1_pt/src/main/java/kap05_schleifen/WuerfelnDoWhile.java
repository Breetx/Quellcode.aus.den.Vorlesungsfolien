package kap05_schleifen;

/**
 * Würfeln von W6-Zufallszahlen, bis eine 6 gewürfelt wurde.
 */
public class WuerfelnDoWhile {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    int wurf;
    do {
      wurf =
          (int) (6 * Math.random()) + 1;
      System.out.format("Wurf: %d.\n",
          wurf);
    } while (wurf != 6);
  }

}
