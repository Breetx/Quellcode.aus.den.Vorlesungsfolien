package kap05_schleifen;

/**
 * Findet die nächst größere Primzahl nach einer Startzahl.
 */
public class FindeNaechstePrimzahl {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    boolean istPrimzahl = false;
    int zahl = 123;
    while (true) {
      zahl++;
      istPrimzahl = true;
      int i = 2;
      while (i < zahl) {
        if (zahl % i == 0) {
          istPrimzahl = false;
          break;
        }
        i++;
      }
      if (istPrimzahl) {
        break;
      }
    }
    System.out.println(zahl);
  }
}
