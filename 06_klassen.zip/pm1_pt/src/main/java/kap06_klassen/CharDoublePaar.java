package kap06_klassen;

/**
 * Repräsentation eines Paares aus einem Zeichen und einer Fließkommazahl.
 */
public class CharDoublePaar {

  /**
   * Zeichen.
   */
  char zeichen;

  /**
   * Fließkommazahl.
   */
  double zahl;
}
