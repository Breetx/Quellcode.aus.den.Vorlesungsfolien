package kap06_klassen;

/**
 * Anwendungsklasse für Brüche.
 *
 */
public class BruchAnwendung {

  /**
   * Programmeinstiegs-Methode.
   */
  public static void main(String[] args) {
    new Bruch();

    Bruch bruch = new Bruch();
    bruch.zaehler = 1;
    bruch.nenner = 9;

    Bruch bruch1 = new Bruch(); // 1/9
    bruch1.zaehler = 1;
    bruch1.nenner = 9;

    Bruch bruch2 = new Bruch(); // 3/7
    bruch2.zaehler = 3 * bruch1.zaehler;
    bruch2.nenner = bruch1.nenner - 2;

  }
}
