package kap06_klassen;

/**
 * Repräsentation eines Tiers.
 */
public class Tier {

  /**
   * Lebensalter des Tieres in Jahren.
   */
  int alter;

  /**
   * Programmeinstiegs-Methode.
   */
  public static void main(String[] args) {

    new Tier();
    new Tier();

    Tier tier = new Tier();
    tier.alter = 23;
    tier.alter++;
    System.out.println(tier.alter);
  }
}
