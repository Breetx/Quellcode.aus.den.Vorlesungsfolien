package kap06_klassen;

/**
 * Ein Bruch besteht aus einem Zähler und einem Nenner.
 */
class Bruch {

  /**
   * Zähler.
   */
  int zaehler;

  /**
   * Nenner.
   */
  int nenner;
}
