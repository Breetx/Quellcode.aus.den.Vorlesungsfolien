package kap06_klassen;

/**
 * Übungscode für den Umgang mit Referenztypen.
 */
public class UebungTierReferenzen {

  /**
   * Programmeinstiegsmethode.
   */
  public static void main(String[] args) {
    Tier tier1 = new Tier();
    Tier tier2 = new Tier();
    Tier tier3 = tier1;
    tier2 = tier3;
    System.out.println(tier2);
  }
}
