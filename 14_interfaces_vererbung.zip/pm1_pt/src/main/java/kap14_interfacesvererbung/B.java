package kap14_interfacesvererbung;

/**
 * Kann von sich sagen, dass es ein "B" ist.
 */
public class B implements ISelbstausgabe {

  @Override
  public void ausgeben() {
    System.out.println("Ich bin ein B.");
  }

}
