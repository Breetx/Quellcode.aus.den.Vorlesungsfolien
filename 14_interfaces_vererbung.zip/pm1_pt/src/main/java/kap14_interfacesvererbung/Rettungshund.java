package kap14_interfacesvererbung;

/**
 * Ein Rettungshund ist ein Hund, der zusätzlich Menschen retten kann.
 */
public class Rettungshund extends Hund {

  /**
   * Rettet einen Menschen.
   */
  public void retteMensch() {
    System.out.println("Mensch erfolgreich gerettet!");
  }

}
