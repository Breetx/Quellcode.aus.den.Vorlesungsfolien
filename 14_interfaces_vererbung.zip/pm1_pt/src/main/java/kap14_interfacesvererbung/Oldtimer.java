package kap14_interfacesvererbung;

/**
 * Repräsentation eines Vermögenswerts vom Typ Oldtimer.
 */
public class Oldtimer implements Vermoegenswert {

  /**
   * Modell-Bezeichnung des Fahrzeugs
   */
  private String modell;

  /**
   * Adresse des Grundstücks.
   */
  private double basisPreis;

  /**
   * Alter in Jahren.
   */
  private int alter;

  /**
   * Konstruktor.
   */
  public Oldtimer(String modell, double basisPreis, int alter) {
    this.modell = modell;
    this.basisPreis = basisPreis;
    this.alter = alter;
  }

  @Override
  public String getName() {
    return modell;
  }

  @Override
  public double getEuroWert() {
    return basisPreis * alter;
  }

  @Override
  public Risiko getRisko() {
    return Risiko.MITTEL;
  }

}
