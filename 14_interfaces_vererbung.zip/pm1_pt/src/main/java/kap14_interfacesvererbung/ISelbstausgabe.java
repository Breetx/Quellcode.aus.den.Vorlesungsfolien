package kap14_interfacesvererbung;

/**
 * Interface für Klassen, die Informationen über sich ausgeben können.
 */
public interface ISelbstausgabe {

  /**
   * Gibt Informationen über sich auf der Konsole aus.
   */
  public void ausgeben();

}
