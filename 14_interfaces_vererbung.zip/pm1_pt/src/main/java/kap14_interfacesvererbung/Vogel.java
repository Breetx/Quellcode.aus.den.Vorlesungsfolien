package kap14_interfacesvererbung;

/**
 * Interface für Vögel die fliegen und singen.
 */
public interface Vogel {

  /**
   * Der Vogel fliegt.
   */
  public void flieg();

  /**
   * Der Vogel "singt" einen Text.
   */
  public void flieg(String text);
}
