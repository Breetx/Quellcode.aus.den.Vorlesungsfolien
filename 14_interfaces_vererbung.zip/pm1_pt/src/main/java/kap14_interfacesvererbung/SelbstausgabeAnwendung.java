package kap14_interfacesvererbung;

/**
 * Testet das Selbstausgabe-Interface.
 */
public class SelbstausgabeAnwendung {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    ISelbstausgabe ausgabe = null;
    // ausgabe.ausgeben();
    ausgabe = new A();
    ausgabe.ausgeben();
    ausgabe = new B();
    ausgabe.ausgeben();
  }

}
