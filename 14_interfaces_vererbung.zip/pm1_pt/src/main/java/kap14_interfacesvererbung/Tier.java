package kap14_interfacesvererbung;

/**
 * Generisches Interface für ein Tier, das Geräusche machen kann.
 */
public interface Tier {

  /**
   * Gibt ein Geräusch von sich.
   */
  public void machGeraeusch();

}
