package kap14_interfacesvererbung;

/**
 * Repräsentation eines Vermögenswerts vom Typ Grundstück.
 */
public class Grundstueck implements Vermoegenswert {

  /**
   * Adresse des Grundstücks.
   */
  private String adresse;

  /**
   * Fläche in m^2.
   */
  private double flaeche;

  /**
   * Preis pro m^2 in EUR.
   */
  private double quadratmeterpreis;

  /**
   * Konstruktor.
   */
  public Grundstueck(String adresse, double flaeche, double quadratmeterpreis) {
    this.adresse = adresse;
    this.flaeche = flaeche;
    this.quadratmeterpreis = quadratmeterpreis;
  }

  @Override
  public String getName() {
    return adresse;
  }

  @Override
  public double getEuroWert() {
    return flaeche * quadratmeterpreis;
  }

  @Override
  public Risiko getRisko() {
    return Risiko.NIEDRIG;
  }

}
