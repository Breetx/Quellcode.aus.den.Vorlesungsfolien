package kap14_interfacesvererbung;

/**
 * Hunde machen "Wuff".
 */
public class Hund implements Tier {

  @Override
  public void machGeraeusch() {
    System.out.println("Wuff");
  }

}
