package kap14_interfacesvererbung;

/**
 * Dieses Interface bietet die öffentliche Schnittstelle für einen
 * Vermögenswert.
 */
public interface Vermoegenswert {
  /**
   * Aufwählungstyp für die Risikoklassen.
   */
  public static enum Risiko {
    NIEDRIG, MITTEL, HOCH
  }

  /**
   * Beschreibung des Vermögenswerts.
   */
  public String getName();

  /**
   * Aktueller Wert in EUR-
   */
  public double getEuroWert();

  /**
   * Einschätzung des Risikos.
   */
  public Risiko getRisko();
}
