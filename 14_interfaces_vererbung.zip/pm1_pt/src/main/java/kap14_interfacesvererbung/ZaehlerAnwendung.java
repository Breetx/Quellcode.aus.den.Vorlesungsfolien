package kap14_interfacesvererbung;

/**
 * Test-Anwendungsklasse für Zähler.
 */
public class ZaehlerAnwendung {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Zaehler zaehler = new Zaehler();
    for (int i = 0; i < 10; i++) {
      zaehler.erhoehen();
      System.out.print(String.format("%d ", zaehler.getWert()));
    }
    System.out.println();
  }
}
