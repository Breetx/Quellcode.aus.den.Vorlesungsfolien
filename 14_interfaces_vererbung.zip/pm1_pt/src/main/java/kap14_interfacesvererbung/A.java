package kap14_interfacesvererbung;

/**
 * Kann von sich sagen, dass es ein "A" ist.
 */
public class A implements ISelbstausgabe {

  @Override
  public void ausgeben() {
    System.out.println("Ich bin ein A.");
  }

}
