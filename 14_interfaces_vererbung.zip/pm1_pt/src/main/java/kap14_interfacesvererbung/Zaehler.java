package kap14_interfacesvererbung;

/**
 * Basisklasse für einen Zähler.
 */
public class Zaehler {
  /**
   * Aktueller Wert.
   */
  protected int wert = 0;

  /**
   * Wert um 1 erhöhen.
   */
  public void erhoehen() {
    wert++;
  }

  /**
   * Getter.
   */
  public int getWert() {
    return wert;
  }

  /**
   * Zähler auf 0 zurücksetzen.
   */
  public void reset() {
    wert = 0;
  }
}
