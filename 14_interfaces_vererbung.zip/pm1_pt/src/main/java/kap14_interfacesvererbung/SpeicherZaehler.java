package kap14_interfacesvererbung;

/**
 * Erweiterte Version des Zaehlers, die sich einen Wert speichern und diesen
 * wiederherstellen kann.
 */
public class SpeicherZaehler extends Zaehler {

  /**
   * Speichert einen Zaehlerwert
   */
  private int speicher = 0;

  /**
   * Merkt sich den aktuellen Wert.
   */
  public void speichern() {
    speicher = wert;
  }

  /**
   * Setzt den Wert auf den gespeicherten Wert zurück.
   */
  public void wiederherstellen() {
    wert = speicher;
  }

}
