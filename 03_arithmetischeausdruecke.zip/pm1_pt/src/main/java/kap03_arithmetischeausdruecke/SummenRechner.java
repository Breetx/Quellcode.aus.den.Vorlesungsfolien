package kap03_arithmetischeausdruecke;

import java.util.Scanner;

/**
 * Berechnet die Summe zweier Zahlen.
 */
public class SummenRechner {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Bitte zwei Zahlen eingeben.");
    int zahl1 = scanner.nextInt();
    int zahl2 = scanner.nextInt();
    scanner.close();
    int summe = zahl1 + zahl2;
    System.out.format("%d + %d = %d", zahl1, zahl2, summe);
  }

}
