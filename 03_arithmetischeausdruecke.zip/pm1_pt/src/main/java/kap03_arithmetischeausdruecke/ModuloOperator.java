package kap03_arithmetischeausdruecke;

/**
 * Testklasse für den Umgang mit dem Modulo-Operator.
 */
public class ModuloOperator {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    System.out.println(4 % 2);
    System.out.println(3 % 3);
    System.out.println(17 % 5);
    System.out.println(5 % 17);
    System.out.println(-5 % -2);
    System.out.println(5 % -2);
    System.out.println(-5 % 2);
  }

}
