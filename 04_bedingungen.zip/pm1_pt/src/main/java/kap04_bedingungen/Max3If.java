/**
 * Prof. Philipp Jenke
 * Hochschule f�r Angewandte Wissenschaften (HAW), Hamburg
 * CG1: Educational Java OpenGL framework with scene graph.
 */
package kap04_bedingungen;

import java.util.Scanner;

/**
 * Berechne die größte dreier Zahlen.
 */
public class Max3If {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    // Eingabe
    System.out.println("Bitte die drei Zahlen eingeben");
    Scanner scanner = new Scanner(System.in);
    int zahl1 = scanner.nextInt();
    int zahl2 = scanner.nextInt();
    int zahl3 = scanner.nextInt();
    scanner.close();

    int groessteZahl = zahl1;
    if (zahl2 > groessteZahl) {
      groessteZahl = zahl2;
    }
    if (zahl3 > groessteZahl) {
      groessteZahl = zahl3;
    }

    // Print result to console
    System.out.println("Größte Zahl aus (" + zahl1 + ", " + zahl2 + ", "
        + zahl3 + ") ist: " + groessteZahl);
  }
}
