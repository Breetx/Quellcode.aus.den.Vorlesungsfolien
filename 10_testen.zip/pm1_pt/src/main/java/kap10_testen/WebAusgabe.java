package kap10_testen;

/**
 * Gibt einen Text auf einer Webseite aus.
 */
public class WebAusgabe {

  /**
   * Referenz auf die Webseite.
   */
  private WebseiteStub webseite;

  /**
   * Konstruktor.
   */
  public WebAusgabe(WebseiteStub webseite) {
    this.webseite = webseite;
  }

  /**
   * Gibt den Text an die Webseite weiter.
   */
  public void gibAus(String text) {
    webseite.stelleDar(text);
  }

}
