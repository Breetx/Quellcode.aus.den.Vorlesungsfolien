package kap10_testen;

/**
 * Stub-Klasse für eine Webseite. Clou: Die Klasse merkt sich den gesendeten
 * Text und kann ihn wieder zurückgeben. Damit können wir testen.
 */
public class WebseiteStub {

  /**
   * Hier wird der letzte Text gespeichert.
   */
  private String letzerText = "";

  /**
   * Dummy-Methode zum Darstellen des Texts.
   */
  public void stelleDar(String text) {
    letzerText = text;
  }

  /**
   * Getter.
   */
  public String getLetzterText() {
    return letzerText;
  }

}
