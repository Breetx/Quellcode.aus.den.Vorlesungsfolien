package kap10_testen;

public class DatenbankStub {

  /**
   * In einer Datenbank würde sich die Anzahl der Nutzer aus dem Inhalt der
   * Datenbank ergeben, hier einfach ein Dummy-Wert.
   */
  public int getAnzahlBenutzer() {
    return 3;
  }

  /**
   * Liefert den Benutzer an der Stelle 'index'. Entsprechend der Angabe in
   * getAnzahlBenutzer() müssen drei Benutzer geliefert werden.
   */
  public Benutzer getBenutzer(int index) {
    switch (index) {
      case 0:
        return new Benutzer("Scholl", "Mehmet", 42);
      case 1:
        return new Benutzer("Häßler", "Ikke", 51);
      case 2:
        return new Benutzer("Walter", "Fritz", 88);
      default:
        return null;
    }
  }
}
