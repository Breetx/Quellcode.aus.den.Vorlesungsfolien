package kap10_testen;

/**
 * Repräsentation eines Benutzers. Damit der Code übersicht bleibt, besteht die
 * Klasse nur aus public Feldern.
 */
public class Benutzer {

  /**
   * (Nach-)Name des Benutzers.
   */
  public String name;

  /**
   * Vorname des Benutzers.
   */
  public String vorname;

  /**
   * Alter des Benutzers (in Jahren).
   */
  public int alter;

  /**
   * Konstruktor zur Initialisierung der Objektvariablen.
   */
  public Benutzer(String name, String vorname, int alter) {
    this.name = name;
    this.vorname = vorname;
    this.alter = alter;
  }

  /**
   * Erzeugt einen String, der den Inhalt des Objektes beschreibt.
   */
  public String toString() {
    return vorname + " " + name + "(" + alter + " Jahre)";
  }

}
