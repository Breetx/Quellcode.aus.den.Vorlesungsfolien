package kap10_testen;

/**
 * Ein Verwaltung für Benutzer in einer Datenbank.
 */
public class Benutzerverwaltung {

  /**
   * Referenz auf die Datenbank (hier der Platzhalter dafür).
   */
  private DatenbankStub datenbank;

  /**
   * Initialisierender Konstruktor.
   */
  public Benutzerverwaltung(DatenbankStub datenbank) {
    this.datenbank = datenbank;
  }

  /**
   * Erzeuge einen String, der die beinhalteten Benutzer darstellt.
   */
  public String toString() {
    String beschreibung = "Anzahl Benutzer: " + datenbank.getAnzahlBenutzer() + "\n";
    for (int index = 0; index < datenbank.getAnzahlBenutzer(); index++) {
      beschreibung += datenbank.getBenutzer(index).toString();
    }
    return beschreibung;
  }
}
