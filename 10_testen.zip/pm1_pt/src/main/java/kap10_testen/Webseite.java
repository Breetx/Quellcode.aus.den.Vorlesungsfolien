package kap10_testen;

/**
 * Dummy-Implementierung einer Webseite - eigentlich ist dies ein Webserver, der
 * dynamisch Webseiten erzeugt.
 */
public class Webseite {

  /**
   * Dummy-Methode zum Darstellen des Texts.
   */
  public void stelleDar(String text) {
    // DUMMY
  }

}
