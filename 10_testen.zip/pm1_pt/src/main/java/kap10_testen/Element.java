package kap10_testen;

/**
 * Die Klasse Element zählt ihre Instanzen zur Laufzeit und gibt den aktuellen
 * Zählerstand im Konstruktor aus.
 * 
 * @author abo781
 *
 */
public class Element {

  /**
   * Statischer Zähler (Objektübergreifend)
   */
  private static int zaehler;

  /**
   * Konstruktor. Inkrementierung des Zählers und Ausgabe.
   */
  public Element() {
    zaehler++;
    System.out.println("Anzahl Elemente: " + zaehler);
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    new Element();
    new Element();
    new Element();
  }
}
