package kap15_vererbung;

/**
 * Abstrakte Variante des Zaehlers. Nicht alle Methoden werden implementiert.
 * Keine Instanziierung möglich.
 *
 */
public abstract class AbstrakterZaehler {

  /**
   * Aktueller Zählerstand.
   */
  protected int wert = 0;

  /**
   * Getter.
   */
  public int getWert() {
    return wert;
  }

  /**
   * Zurücksetzen des Zählers auf 0.
   */
  public void reset() {
    wert = 0;
  }

  /**
   * Erhöhen des Zählers. Diese Methode wird erst in den abgeleiteten Klassen
   * implementiert.
   */
  public abstract void erhoehen();
}
