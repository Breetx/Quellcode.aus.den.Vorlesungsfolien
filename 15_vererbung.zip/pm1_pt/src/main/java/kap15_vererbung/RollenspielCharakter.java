package kap15_vererbung;

/**
 * Elternklasse für alle Rollenspiel-Charaktere
 */
public abstract class RollenspielCharakter {

  /**
   * Names des Charakters
   */
  private String name;

  /**
   * Konstruktor.
   */
  public RollenspielCharakter(String name) {
    this.name = name;
  }

  /**
   * Getter.
   */
  public String getName() {
    return name;
  }

  /**
   * Der Charakter kämpft.
   */
  public abstract void kaempfen();

}
