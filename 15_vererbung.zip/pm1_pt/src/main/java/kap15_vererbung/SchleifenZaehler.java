package kap15_vererbung;

/**
 * Ein SchleifenZaehler beginnt wieder von vorne, wenn er seine Grenze erreicht
 * hat.
 */
public class SchleifenZaehler extends BeschraenkterZaehler {

  /**
   * Konstruktor.
   */
  public SchleifenZaehler(int grenze) {
    super(grenze);
  }

  @Override
  public void erhoehen() {
    if (getWert() == getGrenze()) {
      reset();
    } else {
      super.erhoehen();
    }
  }
}
