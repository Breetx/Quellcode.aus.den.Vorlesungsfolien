package kap15_vererbung;

/**
 * Ein Elf kämpft mit dem Bogen und kann Zauber sprechen.
 */
public class Elf extends RollenspielCharakter {

  /**
   * Konstruktor.
   */
  public Elf(String name) {
    super(name);
  }

  @Override
  public void kaempfen() {
    System.out.println("Schuß mit dem Bogen!");
  }

  /**
   * Ein Elf kann auch einen Zauber sprechen.
   */
  public void zauberSprechen() {
    System.out
        .println("Nîo o Chitaeglir, lasto beth daer: Rimmo nîm Bruinnen Dann in Ulaer.");
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    RollenspielCharakter charakter = new Elf("Legolas");
    charakter.kaempfen();
    if (charakter instanceof Elf) {
      Elf elf = ((Elf) charakter);
      elf.zauberSprechen();
    }
  }

}
