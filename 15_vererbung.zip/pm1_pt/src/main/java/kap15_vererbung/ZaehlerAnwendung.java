package kap15_vererbung;

/**
 * Test-Anwendung für die Zaehler-Klasse
 */
public class ZaehlerAnwendung {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Zaehler zaehler = new BeschraenkterZaehler(5);
    for (int i = 0; i < 10; i++) {
      zaehler.erhoehen();
      System.out.format("%d ", zaehler.getWert());
    }
    System.out.println();

  }
}
