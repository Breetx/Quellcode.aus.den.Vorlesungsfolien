package kap15_vererbung;

/**
 * Ein beschränkter Zähler verhält sich wie ein Zähler, der aber eine Obergrenze
 * für seine Werte hat.
 */
public class BeschraenkterZaehler extends Zaehler {

  /**
   * Grenzwert.-
   */
  private final int grenze;

  /**
   * Konstruktor.
   */
  public BeschraenkterZaehler(int grenze) {
    this.grenze = grenze;
  }

  /**
   * Getter.
   */
  public int getGrenze() {
    return grenze;
  }

  @Override
  public void erhoehen() { // gleiche Signatur
    if (getWert() < grenze) { // neuer Rumpf
      setWert(getWert() + 1);
    }
  }

  /**
   * Erhöht den Zähler in einer gegebenen Schrittweite.
   */
  public void erhoehen(int schrittweite) {
    wert += schrittweite;
  }
}
