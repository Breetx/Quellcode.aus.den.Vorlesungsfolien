package kap15_vererbung;

/**
 * Anwendung für den KaffeeMaschinen-Simulator.
 */
public class KaffeeMaschineAnwendung {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    KaffeeMaschine kaffeeMaschine = new KaffeeMaschine();
    kaffeeMaschine.kaffeeMachen(100);
    kaffeeMaschine = new EspressoMaschine();
    kaffeeMaschine.kaffeeMachen(60);
    ((EspressoMaschine) kaffeeMaschine).kaffeeMachen(60, 120);
  }
}
