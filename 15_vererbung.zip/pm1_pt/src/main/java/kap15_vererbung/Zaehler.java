package kap15_vererbung;

/**
 * Basisklasse für einen Zähler.
 */
public class Zaehler {
  /**
   * Aktueller Wert.
   */
  protected int wert = 0;

  /**
   * Wert um 1 erhöhen.
   */
  public void erhoehen() {
    wert++;
  }

  /**
   * Getter.
   */
  public int getWert() {
    return wert;
  }

  /**
   * Setter.
   */
  public void setWert(int wert) {
    this.wert = wert;
  }

  /**
   * Zähler auf 0 zurücksetzen.
   */
  public void reset() {
    wert = 0;
  }
}
