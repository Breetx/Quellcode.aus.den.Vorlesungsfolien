package kap13_arrays;

/**
 * Tests mit mehrdimensionalen Arrays.
 */
public class MehrdimensionalesArray {

  /**
   * Gibt das Array auf der Konsole aus.
   */
  private static void ausgeben(int[][] array) {
    for (int zeilenIndex = 0; zeilenIndex < array.length; zeilenIndex++) {
      for (int spaltenIndex = 0; spaltenIndex < array[zeilenIndex].length; spaltenIndex++) {
        System.out.format("%4d ", array[zeilenIndex][spaltenIndex]);
      }
      System.out.println();
    }
    System.out.println();
  }

  /**
   * Erweitert die zweite Dimension des Array um 1.
   */
  private static int[][] erweitereZweiteDimension(int[][] array) {
    // Achtung: hier müsste man prüfen, ob das Array mindestens eine Spalte hat!
    int[][] neuesArray = new int[array.length][array[0].length + 1];
    for (int zeilenIndex = 0; zeilenIndex < array.length; zeilenIndex++) {
      for (int spaltenIndex = 0; spaltenIndex < array[zeilenIndex].length; spaltenIndex++) {
        neuesArray[zeilenIndex][spaltenIndex] =
            array[zeilenIndex][spaltenIndex];
      }
      neuesArray[zeilenIndex][array[0].length] = 0;
    }
    return neuesArray;
  }

  /**
   * Erzeugt ein 3D-Array.
   * 
   * @return
   */
  public int[][][] erzeuge3dArray() {
    int[][][] array = { { { 1 } } };
    return array;
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    int[][] array = { { 1, 2, 3 }, { 4, 5, 6 } };
    ausgeben(array);
    array = erweitereZweiteDimension(array);
    ausgeben(array);
  }
}
