package kap13_arrays;

/**
 * Testklasse zum Umgang mit Arrays.
 */
public class Tiere {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    String[] tiere = new String[3];
    tiere[0] = "Affe";
    tiere[1] = "Elefant";
    tiere[2] = "Katze";
    System.out.println(tiere[1]);
    // Alternative zur Initialisierung
    //String[] tiere = { "Affe", "Elefant", "Katze" };

    for (String tier : tiere) {
      System.out.println(tier);
    }

    for (int i = 0; i < tiere.length; i++) {
      if (tiere[i].equals("Affe")) {
        tiere[i] = "Menschenaffe";
      }
    }

  }
}
