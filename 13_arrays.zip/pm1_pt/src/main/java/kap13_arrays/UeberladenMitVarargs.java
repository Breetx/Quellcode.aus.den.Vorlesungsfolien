package kap13_arrays;

/**
 * In dieser Klasse wird das Überladen einer Methode mit einer Signatur
 * getestet, die im Konkflikt zu einer varargs-Methode steht.
 * 
 * @author Philipp Jenke
 *
 */
public class UeberladenMitVarargs {
  /**
   * Methode mit varargs int-Parametern.
   * 
   * @param zahlen
   *          Array der Parameter.
   */
  public void methode(int... zahlen) {
    System.out.println("Methode mit varargs Parametern aufgerufen");
  }

  /**
   * Methode mit zwei int-Parametern.
   * 
   * @param zahl1
   *          Erste Zahl.
   * @param zahl2
   *          Erste Zahl.
   */
  public void methode(int zahl1, int zahl2) {
    System.out.println("Methode mit zwei Parametern aufgerufen");
  }

  /**
   * Programmeinstieg.
   * 
   * @param args
   *          Kommandozeilenargumente.
   */
  public static void main(String[] args) {
    UeberladenMitVarargs umv = new UeberladenMitVarargs();
    umv.methode(23, 42);
    umv.methode(23);
  }

}
