package kap12_wrapperstrings;

import java.util.Scanner;

/**
 * Modifikation von Zeichenketten.
 */
public class ZeichenkettenAenderung {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    System.out.println("Zeichenkette eingeben: ");
    Scanner scanner = new Scanner(System.in);
    String eingabe = scanner.nextLine();
    scanner.close();
    String ausgabe = eingabe.replace('e', 'E');
    ausgabe = ausgabe.trim();
    ausgabe += eingabe.length();
    System.out.println("Eingabe: '" + eingabe + "'");
    System.out.println("Ausgabe: '" + ausgabe + "'");
  }
}
