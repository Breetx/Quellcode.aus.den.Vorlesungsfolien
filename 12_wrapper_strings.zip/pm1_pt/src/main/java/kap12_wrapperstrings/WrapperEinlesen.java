package kap12_wrapperstrings;

import java.util.Scanner;

/**
 * Experiementieren mit Wrapperklassen und Autoboxing.
 */
public class WrapperEinlesen {
  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    System.out.println("Bitte Zahl eingeben.");
    Scanner scanner = new Scanner(System.in);
    double zahl = scanner.nextDouble();
    scanner.close();
    Double zahlWrapper = zahl; // Autoboxing
    int ergebnis = (int) (zahlWrapper.doubleValue()) + 1;
    System.out.println("Ergebnis: " + ergebnis);
  }
}
