package kap12_wrapperstrings;

/**
 * Finde den längsten gemeinsamen Teilstring zweier Strings.
 */
public class LaengsterGemeinsamerTeilstring {

  /**
   * Liefert den längsten gemeinsamen Teilstring.
   */
  public String getLaengsterGemeinsamerTeilstring(String string1, String string2) {
    String ergebnis = "";
    for (int startIndex = 0; startIndex < string1.length(); startIndex++) {
      for (int laenge = 1; laenge < string1.length() - startIndex; laenge++) {
        String testString = string1.substring(startIndex, startIndex + laenge);
        if (string2.contains(testString)
            && testString.length() > ergebnis.length()) {
          ergebnis = testString;
        }
      }
    }
    return ergebnis;
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    LaengsterGemeinsamerTeilstring lgt = new LaengsterGemeinsamerTeilstring();
    System.out.println(lgt.getLaengsterGemeinsamerTeilstring("Tischlerei",
        "Fische"));
  }

}
