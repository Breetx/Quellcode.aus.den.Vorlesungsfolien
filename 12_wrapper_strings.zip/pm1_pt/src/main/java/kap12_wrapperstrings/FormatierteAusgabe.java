package kap12_wrapperstrings;

/**
 * Tesklasse für formatierte Ausgaben.
 */
public class FormatierteAusgabe {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    String name = "Inge";
    int id = 23;
    double wert = 3.1415;
    String ausgabe = String.format("%s (%d): %.2f", name, id, wert);
    System.out.println(ausgabe);

    double zahl = 23.42;
    String text = "Mein Text";
    String string = String.format("%s - %f", text, zahl);
    System.out.println(string);

  }
}
