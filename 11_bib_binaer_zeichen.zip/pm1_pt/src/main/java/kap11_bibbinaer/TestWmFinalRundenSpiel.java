package kap11_bibbinaer;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Testklasse für TestWmFinalRundenSpiel.
 * 
 * @author Philipp Jenke
 *
 */
public class TestWmFinalRundenSpiel {

  @Test
  public void testKonstruktion() {
    String teamDeutschland = "Deutschland";
    String teamArgentinien = "Argentinien";
    String teamBrasilien = "Brasilien";
    String teamHolland = "Holland";
    WmFinalRundenSpiel halbfinale1 =
        new WmFinalRundenSpiel(teamDeutschland, teamBrasilien, null, null, true);
    WmFinalRundenSpiel halbfinale2 =
        new WmFinalRundenSpiel(teamHolland, teamArgentinien, null, null, false);
    WmFinalRundenSpiel finale =
        new WmFinalRundenSpiel(teamDeutschland, teamArgentinien, halbfinale1,
            halbfinale2, true);

    assertEquals(halbfinale1, finale.getVorgaenger1());
    assertEquals(halbfinale2, finale.getVorgaenger2());
    assertEquals(halbfinale1.getGewinner(), finale.getTeam1());
  }
}
