package kap11_bibbinaer;

import java.util.Scanner;

/**
 * Gibt ein Zeichen aus dem Alphabet anhand der Nummerierung aus.
 */
public class ZeichenAnStelle {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Bitte Zeichen eingeben.");
    int index = scanner.nextInt();
    scanner.close();
    if (index < 1 || index > 26) {
      System.out.println("Ungültiger Index!");
      return;
    }
    char zeichen = (char) (index + 96);
    System.out.println("Zeichen an Stelle " + index + ": " + zeichen);
  }
}
