package kap11_bibbinaer;

/**
 * Ein WmFinalRundenSpiel hat zwei Teilnehmer und zwei Vorgänger.
 * 
 * @author Philipp Jenke
 *
 */
public class WmFinalRundenSpiel {

  /**
   * Erstes Vorgänger-Spiel
   */
  private WmFinalRundenSpiel vorgaenger1;

  /**
   * Zweites Vorgänger-Spiel.
   */
  private WmFinalRundenSpiel vorgaenger2;

  /**
   * Erstes teilnehmendes Team. Gewinner des erstes Vorgängerspiels.
   */
  private String team1;

  /**
   * Zweites teilnehmendes Team. Gewinner des zweites Vorgängerspiels.
   */
  private String team2;

  /**
   * Dieses Flag ist wahr, wenn Team1 gewonnen hat, ansonsten faslsch.
   */
  boolean team1Gewinner;

  /**
   * 
   * @param team1
   *          Initialisierung für team1.
   * @param team2
   *          Initialisierung für team2;
   * @param vorgaenger1
   *          Initialisierung für das erste Vorgängerspiel.
   * @param vorgaenger2
   *          Initialisierung für das zweite Vorgängerspiel.
   */
  public WmFinalRundenSpiel(String team1, String team2,
      WmFinalRundenSpiel vorgaenger1, WmFinalRundenSpiel vorgaenger2,
      boolean team1Gewinner) {
    this.team1 = team1;
    this.team2 = team2;
    this.vorgaenger1 = vorgaenger1;
    this.vorgaenger2 = vorgaenger2;
    this.team1Gewinner = team1Gewinner;
  }

  /**
   * Getter.
   * 
   * @return Erster Vorgänger.
   */
  public WmFinalRundenSpiel getVorgaenger1() {
    return vorgaenger1;
  }

  /**
   * Getter.
   * 
   * @return Zweiter Vorgänger.
   */
  public WmFinalRundenSpiel getVorgaenger2() {
    return vorgaenger2;
  }

  /**
   * Getter.
   * 
   * @return Erstes Team.
   */
  public String getTeam1() {
    return team1;
  }

  /**
   * Getter.
   * 
   * @return Zweites Team.
   */
  public String getTeam2() {
    return team2;
  }

  /**
   * Liefert das Team zurück, dass das Spiel gewonnen hat.
   * 
   * @return Name des Gewinnerteams.
   */
  public String getGewinner() {
    return team1Gewinner ? team1 : team2;
  }
}
