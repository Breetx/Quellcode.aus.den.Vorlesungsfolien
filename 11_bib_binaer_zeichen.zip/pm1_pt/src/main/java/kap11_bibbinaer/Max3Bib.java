/**
 * Prof. Philipp Jenke
 * Hochschule f�r Angewandte Wissenschaften (HAW), Hamburg  
 * Lecture demo program.
 */

package kap11_bibbinaer;

import java.util.Scanner;

/**
 * Berechnet die größte dreier Zahlen mit mathematischen Bibliotheksfunktionen.
 */
public class Max3Bib {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    // Eingabe
    Scanner scanner = new Scanner(System.in);
    System.out.println("Bitte drei Ganzzahlen eingeben:");
    int zahl1 = scanner.nextInt();
    int zahl2 = scanner.nextInt();
    int zahl3 = scanner.nextInt();
    scanner.close();

    // Compute max
    final int maxZahl = Math.max(zahl1, Math.max(zahl2, zahl3));

    // Print result to console
    System.out.println("Größte zahl aus (" + zahl1 + ", " + zahl2 + ", "
        + zahl3 + "): " + maxZahl);
  }
}
