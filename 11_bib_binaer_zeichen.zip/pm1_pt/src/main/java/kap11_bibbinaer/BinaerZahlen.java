package kap11_bibbinaer;

/**
 * Tests zu Binärzahlen.
 * 
 * @author Philipp Jenke
 *
 */
public class BinaerZahlen {

  /**
   * Programmeinstieg.
   * 
   * @param args
   *          Kommandozeilenparameter.
   */
  public static void main(String[] args) {
    byte a = (byte) 0b00000010;
    System.out.println(a); // 2
    System.out.println(a << 2); // * 4 = 8

    byte b = (byte) 0b11111110;
    System.out.println(b); // -2
    System.out.println(b >> 1); // / 2 = -1
    System.out.println(0b11111110 >>> 1); // Auffüllen mit 0en -> Vorzeichenwechsel!
  }
}
