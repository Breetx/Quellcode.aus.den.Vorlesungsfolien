package kap16_assoziationenobjectrekursion;

/**
 * Bietet eine statische Methode zur Berechnung der Fakultät einer ganzen Zahl
 * größer 0.
 */
public class Fakultaet {

  /**
   * Berechnet die Fakultät einer ganzen Zahl größer 0 (rekursive Variante).
   */
  public static int fakultaet(int zahl) {
    if (zahl == 1) {
      return 1;
    }
    return zahl * fakultaet(zahl - 1);
  }

  /**
   * Berechnet die Fakultät einer ganzen Zahl größer 0 (iterative Variante).
   */
  public static int fakultaetIterativ(int zahl) {
    int ergebnis = 1;
    for (int zaehler = 2; zaehler <= zahl; zaehler++) {
      ergebnis *= zaehler;
    }
    return ergebnis;
  }
}
