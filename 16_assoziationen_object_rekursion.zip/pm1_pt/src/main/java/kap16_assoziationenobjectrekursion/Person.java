package kap16_assoziationenobjectrekursion;

/**
 * Einfache Repräsentation für eine Person.
 */
public class Person {

  /**
   * Name der Person.
   */
  private String name;

  /**
   * Konstruktor.
   */
  public Person(String name) {
    this.name = name;
  }

  @Override
  public boolean equals(Object anderesObjekt) {
    if (anderesObjekt instanceof Person) {
      // Fall das andere Objekt auch eine Person ist, vergleiche Namen.
      return name.equals(((Person) anderesObjekt).name);
    }
    // Ansonsten: in jedem Fall false
    return false;
  }
}
