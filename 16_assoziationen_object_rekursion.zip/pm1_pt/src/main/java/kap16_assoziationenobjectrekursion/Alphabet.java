package kap16_assoziationenobjectrekursion;

/**
 * Erzeugt eine Alphabet-Zeichenkette.
 */
public class Alphabet {

  /**
   * Iterative Erzeugung einer Alphabet-Zeichenkette
   * ("abcdefghijklmnopqrstuvwxyz").
   */
  public static String erzeugeAlphabetIterativ() {
    String ergebnis = "";
    for (int i = 0; i < 26; i++) {
      ergebnis += (char) ('a' + i);
    }
    return ergebnis;
  }

  /**
   * Rekursive Erzeugung einer Alphabet-Zeichenkette
   * ("abcdefghijklmnopqrstuvwxyz").
   */
  public static String erzeugeAlphabetrekursiv() {
    return erzeugeAlphabetrekursivHilf(25);
  }

  /**
   * Rekursive Hilfsmethode für erzeugeAlphabetrekursiv.
   */
  public static String erzeugeAlphabetrekursivHilf(int index) {
    if (index == 0) {
      return "a";
    } else {
      return erzeugeAlphabetrekursivHilf(index - 1) + (char) (index + 'a');
    }
  }
}
