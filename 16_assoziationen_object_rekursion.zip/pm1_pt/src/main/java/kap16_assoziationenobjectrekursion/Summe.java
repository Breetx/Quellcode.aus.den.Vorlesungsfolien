package kap16_assoziationenobjectrekursion;

/**
 * Berechnung der ganzen Zahlen von 1...n.
 */
public class Summe {

  /**
   * Berechnung der ganzen Zahlen von 1...n. n muss >= 1 sein.
   */
  public static int summe(int n) {
    if (n == 1) {
      return 1;
    }
    return n + summe(n - 1);
  }
}
