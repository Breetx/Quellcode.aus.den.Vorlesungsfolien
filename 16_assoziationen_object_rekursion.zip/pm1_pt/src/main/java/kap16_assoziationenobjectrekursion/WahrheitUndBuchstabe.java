package kap16_assoziationenobjectrekursion;

/**
 * Diese Klasse repräsentiert die Kombination aus einem Wahrheitswert und einem
 * Buchstaben (a-z).
 */
public class WahrheitUndBuchstabe {

  /**
   * Aktueller Wahrheitswert.
   */
  private boolean wahrheitswert;

  /**
   * Aktueller Buchstabe, es sind nur Kleinbuchstaben a-z erlaubt.
   */
  private char buchstabe;

  /**
   * Konstruktor.
   */
  public WahrheitUndBuchstabe(boolean wahrheitswert, char buchstabe) {
    this.wahrheitswert = wahrheitswert;
    this.buchstabe = buchstabe;
  }

  @Override
  public int hashCode() {
    // Buchstabencode wird als Zahlenwert zwischen 0 und 26 interpretiert. Falls
    // wahrheitswert true ist, wird auf den HashCode 26 addiert. Damit ist der
    // HashCode eindeutig und aus [0,52]
    return (int) buchstabe - (int) 'a' + (wahrheitswert ? 26 : 0);
  }

  @Override
  public boolean equals(Object anderesObjekt) {
    if (!(anderesObjekt instanceof WahrheitUndBuchstabe)) {
      return false;
    }
    // Da der HashCode eindeutig ist, darf ich ihn für die Gleichheit verwenden,
    // ansonsten nur um ungleiche Instanzen zu finden!
    return hashCode() == anderesObjekt.hashCode();
  }
}
