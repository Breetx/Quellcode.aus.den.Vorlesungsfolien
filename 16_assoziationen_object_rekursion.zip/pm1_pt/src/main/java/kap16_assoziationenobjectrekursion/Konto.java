package kap16_assoziationenobjectrekursion;

/**
 * Eine sehr einfache Repräsentation für ein Konto bestehend aus einem
 * Kontostand und einem Kontoinhaber.
 */
public class Konto {

  /**
   * Aktueller Kontostand
   */
  private double kontostand;

  /**
   * Inhaber des Kontos.
   */
  private Person kontoinhaber;

  /**
   * Konstruktor.
   */
  public Konto(double kontostand, Person kontoinhaber) {
    this.kontostand = kontostand;
    this.kontoinhaber = kontoinhaber;
  }

  @Override
  public boolean equals(Object anderesObjekt) {
    if (!(anderesObjekt instanceof Konto)) {
      // Kein kompatibler Typ: false
      return false;
    }
    Konto anderesKonto = (Konto) anderesObjekt;
    // Vergleiche Kontostand und Kontoinhaber
    return Math.abs(kontostand - anderesKonto.kontostand) < 1e-5
        && kontoinhaber.equals(anderesKonto.kontoinhaber);
  }
}
