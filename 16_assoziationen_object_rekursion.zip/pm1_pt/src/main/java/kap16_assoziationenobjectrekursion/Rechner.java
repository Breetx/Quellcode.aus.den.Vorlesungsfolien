package kap16_assoziationenobjectrekursion;

/**
 * Rechner für Grundrechenarten mit rekursiver Implementierung.
 */
public class Rechner {

  /**
   * Addieren der beiden ganzen Zahlen zahl1 und zahl2. Beide müssen >= 0 sein.
   */
  public int addiere(int zahl1, int zahl2) {
    if (zahl2 == 0) {
      return zahl1;
    } else {
      return addiere(zahl1 + 1, zahl2 - 1);
    }
  }

}
