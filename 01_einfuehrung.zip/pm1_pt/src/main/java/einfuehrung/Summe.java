package einfuehrung;

/**
 * Berechnet die Summe aller nat. Zahlen 1 .. n.
 */
class Summe {

  public static void main(String[] args) {
    // Variablen (Zutaten)
    int zahl;
    int ergebnis;
    int zaehler;

    // Verarbeitung: Anweisungen (Zubereitung)
    zahl = 6;
    ergebnis = 0;
    zaehler = 1;
    while (zaehler <= zahl) {
      ergebnis = ergebnis + zaehler;
      zaehler = zaehler + 1;
    }

    // Ausgabe
    System.out.println(ergebnis);
  }
}