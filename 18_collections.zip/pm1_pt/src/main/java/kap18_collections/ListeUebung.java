package kap18_collections;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * Erzeugen einer Linked-List aus Zahlen, Ausgabe auf der Konsole.
 */
public class ListeUebung {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    List<Integer> liste =
        new LinkedList<Integer>(Arrays.asList(new Integer(
            23), new Integer(42), new Integer(12),
            new Integer(11)));

    String ergebnis = "{";
    for (int i = 0; i < liste.size(); i++) {
      ergebnis +=
          String.format("%d"
              + ((i < liste.size() - 1) ? ", " : ""),
              liste.get(i));
    }
    ergebnis += "}";
    System.out.println(ergebnis);

    // Durchlaufen mit for-Schleife
    for (Iterator<Integer> it = liste.iterator(); it
        .hasNext();) {
      System.out.println(it.next());
    }

    // Durchlaufen mit while-Schleife
    Iterator<Integer> it = liste.iterator();
    while (it.hasNext()) {
      System.out.println(it.next());
    }
  }
}
