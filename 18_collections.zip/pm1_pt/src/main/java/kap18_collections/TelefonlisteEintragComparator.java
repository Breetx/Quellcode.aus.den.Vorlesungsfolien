package kap18_collections;

import java.util.Comparator;

/**
 * Komparator für Telefonlisten-Einträge.
 */
public class TelefonlisteEintragComparator implements
    Comparator<TelefonlistenEintrag> {

  @Override
  public int compare(TelefonlistenEintrag eintrag1,
      TelefonlistenEintrag eintrag2) {
    return eintrag1.compareTo(eintrag2);
  }

}
