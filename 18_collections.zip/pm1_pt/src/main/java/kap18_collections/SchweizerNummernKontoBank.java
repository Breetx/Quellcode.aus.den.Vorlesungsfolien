package kap18_collections;

import java.util.HashMap;
import java.util.Map;

/**
 * In der Bank werden Kontostände durch (eindeutige) Nummern referenziert.
 */
public class SchweizerNummernKontoBank {
  /**
   * Liste der Konten als Schlüssel-Wert-Paare. Die Kontonummer ist der
   * Schlüssel
   */
  private Map<Integer, Float> konten =
      new HashMap<Integer, Float>();

  /**
   * Neues Konto hinzufügen. Achtung: keine Überprüfung, ob die Kontonummer
   * bereits verwendet wird.
   */
  public void kontoHinzufueegen(int kontonummer,
      float kontostand) {
    konten.put(new Integer(kontonummer), new Float(
        kontostand));
  }

  /**
   * Liefert den aktuellen Kontostand für eine gegebene Kontonummer;
   */
  public float getKontostand(int kontonummer) {
    return konten.get(kontonummer);
  }

  /**
   * Neuen Kontostand für ein Konto setzen. Achtung: Konto muss bereits
   * existieren.
   */
  public void setzeKontostand(int kontonummer,
      float neuerKontostand) {
    if (konten.get(kontonummer) == null) {
      System.out.println("Ungültge Kontonummer!");
    }
    konten.put(kontonummer, neuerKontostand);
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    SchweizerNummernKontoBank bank =
        new SchweizerNummernKontoBank();
    int kontonummer1 = 3672648;
    int kontonummer2 = 873894795;
    int kontonummer3 = 673546723;
    bank.kontoHinzufueegen(kontonummer1, 53454.34f);
    bank.kontoHinzufueegen(kontonummer2, 42343.43f);
    bank.kontoHinzufueegen(kontonummer3, 94237.37f);
    System.out.format("Aktueller Kontstand für %d: %.2f.\n",
        kontonummer1, bank.getKontostand(kontonummer1));
    System.out.format("Aktueller Kontstand für %d: %.2f.\n",
        kontonummer2, bank.getKontostand(kontonummer2));
    System.out.format("Aktueller Kontstand für %d: %.2f.\n",
        kontonummer3, bank.getKontostand(kontonummer3));
  }
}
