package kap18_collections;

/**
 * Ein Eintrag in einer Telefonliste besteht aus einem Namen und einer Nummer.
 */
public class TelefonlistenEintrag implements
    Comparable<TelefonlistenEintrag> {
  /**
   * Name des Eintrags.
   */
  private final String name;

  /**
   * Telefonnummer des Eintrags.
   */
  private final String nummer;

  @Override
  public int compareTo(TelefonlistenEintrag andererEintrag) {
    return getName().compareTo(andererEintrag.getName());
  }

  /**
   * Initialisierender Konstruktor.
   */
  public TelefonlistenEintrag(String name, String nummer) {
    this.name = name;
    this.nummer = nummer;
  }

  /**
   * Getter.
   */
  public String getName() {
    return name;
  }

  /**
   * Getter.
   */
  public String getNummer() {
    return nummer;
  }

  @Override
  public String toString() {
    return String.format("%s: %s", getName(), getNummer());
  }
}
