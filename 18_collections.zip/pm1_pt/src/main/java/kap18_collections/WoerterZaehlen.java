package kap18_collections;

import java.util.HashSet;
import java.util.Set;

/**
 * Liefert die Anzahl der Wörter in einem Text. Identische Wörter werden nicht
 * doppelt gezählt.
 */
public class WoerterZaehlen {
  /**
   * Berechne Anzahl Wörter in Text.
   */
  public int zaehleWoerter(String text) {
    // Menge erzeugen
    Set<String> wordSet = new HashSet<String>();
    // Text bei Leerzeichen auftrenne -> regulärer Ausdrücke (siehe PM2)
    for (String word : text.split("\\s+")) {
      wordSet.add(word);
    }
    // Anzahl Wörter = Anzahl Elemente in Menge.
    return wordSet.size();
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    WoerterZaehlen woerterZaehlen = new WoerterZaehlen();
    String text =
        "Wenn Fliegen fliegen fliegen Fliegen Fliegen     nach.";
    System.out.format("Text: '%s'.\n", text);
    System.out.format("Anzahl Wörter in Text: %d.\n",
        woerterZaehlen.zaehleWoerter(text));
  }
}
