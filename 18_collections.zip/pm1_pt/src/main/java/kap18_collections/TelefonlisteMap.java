package kap18_collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

/**
 * Eine Telefonliste verwaltet Einträge von Kontakten.
 */
public class TelefonlisteMap {
  /**
   * Die Liste der Einträge wird als Map verwaltet.
   **/
  private Map<String, String> eintraege =
      new HashMap<String, String>();

  /**
   * Es sollen Telefonnummern und dazugehörige Namen in die Liste eingetragen
   * bzw. verändert werden.
   */
  public void eintragHinzufuegen(String name, String nummer) {
    eintraege.put(name, nummer);
  }

  /**
   * Es soll nach einem Namen gesucht werden. Ergebnis: Telefonnummer oder null,
   * falls nicht gefunden.
   */
  public String getNummer(String name) {
    return eintraege.get(name);
  }

  /**
   * Es soll ein Eintrag aus der Liste gelöscht werden.
   */
  public void eintragEntfernen(String name) {
    eintraege.remove(name);
  }

  @Override
  public String toString() {
    // Hinweis: Lösung mit Lambdas -> PM2, Idee: Map -> Menge von Paaren
    // (EntrySet), jedes Paar in String konvertieren (map), Strings
    // konkatenieren (collect).
    return eintraege
        .entrySet()
        .stream()
        .map(
            (Entry<String, String> eintrag) -> {
              return String.format("%s: %s",
                  eintrag.getKey(), eintrag.getValue());
            }).collect(Collectors.joining(", "));
  }
}