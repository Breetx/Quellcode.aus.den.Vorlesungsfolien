package kap18_collections;

/**
 * Testanwendung für die Telefonliste.
 */
public class TelefonlistenAnwendung {

  public static void main(String[] args) {
    testeTelefonliste();
    testeTelefonlisteMap();
  }

  /**
   * Test mit einer Telefonliste.
   */
  public static void testeTelefonliste() {
    System.out.println("---");
    Telefonliste telefonliste = new Telefonliste();
    String scholl = "Mehmet Scholl";
    String zizu = "Zizu Zidane";
    String ikke = "Ikke Häßler";
    telefonliste.eintragHinzufuegen(scholl, "1121718");
    telefonliste.eintragHinzufuegen(ikke, "736712027");
    telefonliste.eintragHinzufuegen(zizu, "674237423");

    // System.out.format("Nummer von %s: %s\n", scholl,
    // telefonliste.getNummer(scholl));
    // System.out.format("Nummer von %s: %s\n", zizu,
    // telefonliste.getNummer(zizu));
    // System.out.println(telefonliste);
    // telefonliste.eintragEntfernen(ikke);
    // System.out.println(telefonliste);
    // telefonliste.eintragEntfernen(scholl);

    System.out.println(telefonliste);
    telefonliste.sortieren();
    System.out.println(telefonliste);
  }

  /**
   * Test mit einer Telefonliste, die mit einer Map arbeitet.
   */
  public static void testeTelefonlisteMap() {
    System.out.println("---");
    TelefonlisteMap telefonliste = new TelefonlisteMap();
    String scholl = "Mehmet Scholl";
    String zizu = "Zizu Zidane";
    String ikke = "Ikke Häßler";
    telefonliste.eintragHinzufuegen(scholl, "1121718");
    telefonliste.eintragHinzufuegen(ikke, "736712027");
    telefonliste.eintragHinzufuegen(zizu, "674237423");

    System.out.format("Nummer von %s: %s\n", scholl,
        telefonliste.getNummer(scholl));
    System.out.format("Nummer von %s: %s\n", zizu,
        telefonliste.getNummer(zizu));
    System.out.println(telefonliste);
    telefonliste.eintragEntfernen(ikke);
    System.out.println(telefonliste);
    telefonliste.eintragEntfernen(scholl);

    System.out.println(telefonliste);
  }
}
