package kap18_collections;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Eine Telefonliste verwaltet Einträge von Kontakten.
 */
public class Telefonliste {
  /**
   * Die Liste der Einträge wird als Collection (List) verwaltet.
   **/
  private List<TelefonlistenEintrag> eintraege =
      new LinkedList<TelefonlistenEintrag>();

  /**
   * Es sollen Telefonnummern und dazugehörige Namen in die Liste eingetragen
   * bzw. verändert werden.
   */
  public void eintragHinzufuegen(String name, String nummer) {
    eintraege.add(new TelefonlistenEintrag(name, nummer));
  }

  /**
   * Es soll nach einem Namen gesucht werden. Ergebnis: Telefonnummer oder null,
   * falls nicht gefunden.
   */
  public String getNummer(String name) {
    // "Traditionelle" for-Schleife
    for (TelefonlistenEintrag eintrag : eintraege) {
      if (eintrag.getName().equals(name)) {
        return eintrag.getNummer();
      }
    }

    // Iterator mit while-Schleife
    Iterator<TelefonlistenEintrag> it =
        eintraege.iterator();
    while (it.hasNext()) {
      TelefonlistenEintrag eintrag = it.next();
      if (eintrag.getName().equals(name)) {
        return eintrag.getNummer();
      }
    }

    // Iterator mit for-Schleife
    for (it = eintraege.iterator(); it.hasNext();) {
      TelefonlistenEintrag eintrag = it.next();
      if (eintrag.getName().equals(name)) {
        return eintrag.getNummer();
      }
    }

    return null;
  }

  /**
   * Es soll ein Eintrag aus der Liste gelöscht werden.
   */
  public void eintragEntfernen(String name) {
    for (Iterator<TelefonlistenEintrag> it =
        eintraege.iterator(); it.hasNext();) {
      TelefonlistenEintrag eintrag = it.next();
      if (eintrag.getName().equals(name)) {
        it.remove();
      }
    }
  }

  @Override
  public String toString() {
    // Hinweis: Lösung mit Lambdas -> PM2, Idee: Einträge als Stream, jeden
    // Eintrag in String konvertieren (map), Strings konkatenieren (collect).
    return eintraege.stream()
        .map((TelefonlistenEintrag eintrag) -> {
          return eintrag.toString();
        }).collect(Collectors.joining(", "));
    
    // Lösung mit Iterator (ohne Lambdas)
    // Iterator mit for-Schleife
    // String ergebnis = "";
    // for (Iterator<TelefonlistenEintrag>it = eintraege.iterator();
    // it.hasNext();) {
    // TelefonlistenEintrag eintrag = it.next();
    // ergebnis += String.format("%s, ", eintrag);
    // }
    // return ergebnis;
  }

  /**
   * Sortieren der Einträge nach Name
   */
  public void sortieren() {
    // Verwendung des Interfaces Comparable in TelefonlistenEintrag
    Collections.sort(eintraege);

    // Verwendung eines Komparators
    Collections.sort(eintraege,
        new TelefonlisteEintragComparator());
  }
}