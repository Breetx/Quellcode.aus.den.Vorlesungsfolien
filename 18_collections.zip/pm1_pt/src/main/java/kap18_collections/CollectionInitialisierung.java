package kap18_collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class CollectionInitialisierung {
  public static void main(String[] args) {

    // Verkettete Liste erzeugen
    List<String> listeLinkedList = new LinkedList<String>();

    // Verkettete Liste in ArrayList umwandlen.
    List<String> listeArrayList =
        new ArrayList<String>(listeLinkedList);
    System.out.println(listeArrayList);

    // Array vom Typ Object erzeugen.
    Object[] arrayVonEintraegen = listeLinkedList.toArray();

    // Array vom gleichen Typ (hier: String) erzeugen.
    TelefonlistenEintrag[] listeArray =
        new TelefonlistenEintrag[listeLinkedList.size()];
    listeLinkedList.toArray(arrayVonEintraegen);
    System.out.println(listeArray);

    // Liste mit mehreren Elementen initialisierung
    List<String> listeMitInit =
        Arrays.asList("Jan", "Hein", "Klaas", "Pit");

    Iterator<String> iter = listeMitInit.iterator();
    while (iter.hasNext()) {
      String stadtteil = iter.next();
      System.out.println(stadtteil);
    }
  }
}
