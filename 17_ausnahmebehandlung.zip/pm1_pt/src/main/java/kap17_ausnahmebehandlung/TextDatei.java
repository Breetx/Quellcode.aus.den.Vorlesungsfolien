package kap17_ausnahmebehandlung;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Dummy-Klasse für die Übung des Zugriffs auf eine Datei.
 */
public class TextDatei {

  /**
   * Logger-Objekt.
   */
  private final Logger logger;

  public TextDatei() {
    logger = Logger.getLogger(TextDatei.class.getName());
    logger.setLevel(Level.ALL);
    FileHandler fileHandler = null;
    try {
      fileHandler = new FileHandler("logdatei.txt");
    } catch (SecurityException e) {
      logger.log(Level.SEVERE,
          "Fehler beim Anlegen der Log-Datei", e);
    } catch (IOException e) {
      logger.log(Level.SEVERE,
          "Fehler beim Anlegen der Log-Datei", e);
    }
    logger.addHandler(fileHandler);
  }

  /**
   * Öffnen der Datei.
   */
  public void oeffnen() throws FileNotFoundException {
    logger.log(Level.INFO, "Datei geöffnet.");
  }

  /**
   * Lesen einer Zeile.
   */
  public void zeileLesen() throws IOException {
    if (Math.random() < 0.4) {
      // Per Zufall wird hier und da die Exception ausgelöst.
      IOException exception = new IOException();
      logger.log(Level.SEVERE, "zeileLesen", exception);
      throw exception;
    }
    logger.log(Level.INFO, "Zeile gelesen.");
  }

  /**
   * Schliessen der Datei.
   */
  public void schliessen() {
    logger.log(Level.INFO, "Datei geschlossen.");
  }

  public static void main(String[] args) {
    TextDatei textDatei = new TextDatei();
    try {
      textDatei.oeffnen();
      textDatei.zeileLesen();

    } catch (FileNotFoundException fileNotFoundException) {
      System.out.println("Datei nicht gefunden.");
    } catch (IOException ioException) {
      System.out.println("Fehler beim Dateizugriff.");
    } finally {
      textDatei.schliessen();
    }
  }
}
