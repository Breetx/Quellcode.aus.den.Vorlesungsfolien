package kap17_ausnahmebehandlung;

/**
 * Test: Zugriff auf Zahlen-Array.
 */
public class ZugriffZahlenArray {

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    try {
      double[] doubleArray = { 1.0, 2.0, 3.0 };
      System.out.println(doubleArray[5]);
    } catch (Exception e) {
      System.out.println("Exception: " + e.getMessage());
    }
  }
}
