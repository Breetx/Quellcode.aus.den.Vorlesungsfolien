package kap17_ausnahmebehandlung;

/**
 * Gibt an, dass ein Spannungschwellwert unterschritten wurde.
 */
public class SpannungsUnterversorgungException
    extends Exception {
  /**
   * 
   */
  private static final long serialVersionUID =
      -4338933573569787558L;

  /**
   * Konstruktor.
   */
  public SpannungsUnterversorgungException(
      double spannungsSchwellwert,
      double aktuellerSpannungsWert) {
    super(
        String
            .format(
                "Aktueller Spannungswert %.2f unter Schwellwert %.2f.",
                aktuellerSpannungsWert,
                spannungsSchwellwert));
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    try {
      throw new SpannungsUnterversorgungException(
          3.3, 2.9);
    } catch (SpannungsUnterversorgungException exception) {
      System.out.println("Exception: "
          + exception.getMessage());
    }
  }

}
