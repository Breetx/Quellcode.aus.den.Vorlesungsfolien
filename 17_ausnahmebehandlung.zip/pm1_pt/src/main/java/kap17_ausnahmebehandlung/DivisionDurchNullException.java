package kap17_ausnahmebehandlung;

/**
 * Eigene Exception, die angibt, dass eine Division durch 0 versucht wurde.
 */
public class DivisionDurchNullException
    extends Exception {

  /**
   * Konstruktor.
   */
  public DivisionDurchNullException() {
    super("Division durch 0");
  }

  /**
   * 
   */
  private static final long serialVersionUID =
      -5227986757424771222L;

}
