package kap17_ausnahmebehandlung;

import java.util.Scanner;

/**
 * Sichere Benutzereingabe.
 *
 */
public class BenutzerEingabe {

  /**
   * Programmeinstieg. Eingabe als Zahl und >= 0 gefordert
   */
  public static void main(String[] args) throws NumberFormatException {
    int eingabe;
    try {
      Scanner scanner = new Scanner(System.in);
      // nextInt() löst evtl. Exception aus!
      eingabe = scanner.nextInt();
      // eingabe <= 0 --> ebenfalls Exception auslösen!
      if (eingabe <= 0) {
        scanner.close();
        throw new NumberFormatException("Wert < 0");
      }
      scanner.close();
    } catch (NumberFormatException exception) {
      // Fehlerbehandlung für falsche Eingabe
      System.out.println("Ungültige Eingabe: " + exception.getMessage());
    } catch (IllegalStateException exception) {
      System.out.println("Scanner nicht offen: " + exception.getMessage());
    }
  }
}
