package kap17_ausnahmebehandlung;

/**
 * Berechnet das Divisionsergebnis zweier Fliesskommazahlen.
 */
public class Division {

  /**
   * Berechnet das Divisionsergebnis aus zaehler und nenner. Wirft eine
   * Exception, wenn der nenner 0 ist.
   */
  public double division(
      double zaehler, double nenner)
      throws DivisionDurchNullException {
    if (Math.abs(nenner) < 1e-5) {
      throw new DivisionDurchNullException();
    }
    return zaehler / nenner;
  }

  /**
   * Programmeinstieg.
   */
  public static void main(String[] args) {
    Division division = new Division();
    try {
      System.out.println(division
          .division(23, 43));
      System.out.println(division
          .division(23, 0));
    } catch (DivisionDurchNullException e) {
      System.out
          .println("Fehler: Division durch 0");
    }
  }

}
